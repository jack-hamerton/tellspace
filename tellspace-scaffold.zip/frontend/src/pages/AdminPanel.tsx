import React from 'react'
export default function AdminPanel(){
  return (
    <div className='card'>
      <h3>Admin Moderation (hidden)</h3>
      <p>Access this panel only via admin flows. IP-restriction & token checks are backend responsibilities.</p>
    </div>
  )
}
