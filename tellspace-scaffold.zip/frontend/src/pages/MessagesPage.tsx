import React from 'react'
export default function MessagesPage(){
  return (
    <div className='card'>
      <h3>Messages (skeleton)</h3>
      <p>Conversation list and chat window skeleton.</p>
    </div>
  )
}
